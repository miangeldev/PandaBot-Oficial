#Run uvicorn fastapi app:app
#!/bin/bash
uvicorn app:app --host 0.0.0.0 --port 8000 --reload --timeout-keep-alive 60 --log-level info